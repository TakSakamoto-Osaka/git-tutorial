﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIL.Hyd.ToolUtilities.Network
{
    public class ADUser
    {
        /// <summary>ログインユーザー名</summary>
        public string UserName { private set; get; }

        /// <summary>名前（漢字）</summary>
        public string FirstName { private set; get; }

        /// <summary>苗字（漢字）</summary>
        public string LastName { private set; get; }

        /// <summary>社員コード</summary>
        public string EmployeeNumber { private set; get; }

        /// <summary>会社名</summary>
        public string CompanyName { private set; get; }
        
        /// <summary>社員の種類</summary>
        public EEmployeeType EmployeeType { private set; get; }

        /// <summary>事業部名 部署名</summary>
        public string DepartmentName { private set; get; }

        /// <summary>メールアドレス</summary>
        public string EMail { private set; get; }

        /// <summary>内線番号</summary>
        public string TelephoneNumber { private set; get; }

        public ADUser(ResultPropertyCollection property)
        {
            try
            {
                UserName = property["cn"][0].ToString();
                FirstName = property["givenName"][0].ToString();
                LastName = property["sn"][0].ToString();
                EmployeeNumber = property["employeeNumber"][0].ToString();
                CompanyName = property["company"][0].ToString();

                switch (property["employeeType"][0].ToString())
                {
                    case "正社員":
                        EmployeeType = EEmployeeType.Regular;
                        break;
                    default:
                        EmployeeType = EEmployeeType.Other;
                        break;
                }
                

                if (property.Contains("department"))
                {
                    DepartmentName = property["department"][0].ToString();
                }
                else
                {
                    DepartmentName = string.Empty;
                }

                if (property.Contains("mail"))
                {
                    EMail = property["mail"][0].ToString();
                }
                else
                {
                    EMail = string.Empty;
                }

                if (property.Contains("telephoneNumber"))
                {
                    TelephoneNumber = property["telephoneNumber"][0].ToString();
                }
                else
                {
                    TelephoneNumber = string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }
    }
}
