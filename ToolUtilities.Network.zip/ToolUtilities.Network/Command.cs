﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIL.Hyd.ToolUtilities.Network
{
    /// <summary>
    /// ネットワーク関連コマンドクラス
    /// </summary>
    public static class Command
    {
        /// <summary>
        /// Pingコマンド
        /// </summary>
        /// <param name="hostNameOrAddress">接続先IPアドレス</param>
        /// <returns></returns>
        public static bool Ping( string hostNameOrAddress )
        {   
            bool isSuccess = false;

            try {
                using ( var ping = new System.Net.NetworkInformation.Ping() ) {
                    try {
                        var reply = ping.Send( hostNameOrAddress );

                        if ( System.Net.NetworkInformation.IPStatus.Success == reply.Status ) {
                            isSuccess = true;
                        }
                    } catch ( Exception ex ) {
                        throw new Exception( ex.Message, ex );
                    }
                }
            } catch ( Exception ex ) {
                throw new Exception( ex.Message, ex );
            }

            return isSuccess;
        }
    }
}
