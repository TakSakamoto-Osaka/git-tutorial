﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.NetworkInformation;
using System.Diagnostics;
using System.ServiceProcess;

namespace DIL.Hyd.ToolUtilities.Network
{
    public class NICInfo
    {
        /// <summary>NIC名</summary>
        public string NICName { set; private get; }

        /// <summary>説明</summary>
        public string Description { get; private set; }

        /// <summary>種類</summary>
        public string NICType { get; private set; }

        /// <summary>MACアドレス</summary>
        public string MACAddress { get; private set; }

        /// <summary>IPアドレス</summary>
        public string IPAddress { get; private set; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="NICName">NIC名</param>
        public NICInfo( string NICName )
        {
            try {
                this.NICName = NICName;                             //  NIC名

                //  すべてのネットワークインターフェイスを取得する
                NetworkInterface[] nis = NetworkInterface.GetAllNetworkInterfaces();

                //  接続中のNICで引数の名前と等しいもの取得
                var ni = nis.First( x => x.OperationalStatus    == OperationalStatus.Up &&
                                             x.NetworkInterfaceType != NetworkInterfaceType.Loopback &&
                                             x.NetworkInterfaceType != NetworkInterfaceType.Tunnel &&
                                             x.Name                 == NICName );

                

                this.Description = ni.Description;
                this.NICType     = ni.NetworkInterfaceType.ToString();
                this.MACAddress  = ni.GetPhysicalAddress().ToString();

                //  構成情報、アドレス情報を取得する
                IPInterfaceProperties ipips = ni.GetIPProperties();

                if ( ipips != null ) {
                    foreach ( UnicastIPAddressInformation ip in ipips.UnicastAddresses ) {
                        this.IPAddress = ip.Address.ToString();
                    }

                } else {
                    throw ( new Exception("IPアドレス取得エラー") );
                }

            } catch {
                throw;
            }
        }

    }
}
