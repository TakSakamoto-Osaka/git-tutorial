﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.DirectoryServices;
using static DIL.Hyd.ToolUtilities.Network.ProtocolType;

namespace DIL.Hyd.ToolUtilities.Network
{
    public class LoginAuthority : RestAPICom
    {
        public LoginAuthority(string strHTTPSrvIP = "127,0,0,1", ProtocolType ProtocolTypeVal = HTTP, int portNo = 80) : base(strHTTPSrvIP, ProtocolTypeVal, portNo)
        {
            WellKnownTopDir = "mfai";
        }

        /// <summary>
        /// POSTリクエストによるログイン情報の取得
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns>HTTPレスポンス</returns>
        public async Task<HttpResponseMessage> APILogin(string userName, string password)
        {
            try
            {
                List<string> strDirs = new List<string>();

                if (PortNo == 80 || PortNo == 443)
                {                          //  Well knownポートの場合
                    strDirs.Add(WellKnownTopDir);
                }

                strDirs.AddRange(new string[] { "api", "auth", "login" });

                BodyContent content = new BodyContent(userName, password);      //  Body部オブジェクト生成
                string jsonStr = JsonSerializer.Serialize(content);           //  JSON文字列生成

                return (await PostCmd(strDirs, strPostData: jsonStr, DirLastSlashNone: true));      //  Post通信(Dir部の最後のスラッシュを付加しない)

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                throw;
            }
        }

        /// <summary>
        /// LDAP認証によるユーザ情報の取得
        /// </summary>
        /// <param name="loginUser"></param>
        /// <param name="password"></param>
        /// <returns>ユーザ情報（失敗時はNULL）</returns>
        public ADUser LdapLogin(string loginUser, string password, string ldapServerName = "LDAP://DKGDC-Y.DIL.DKG")
        {
            string userName = $"dil\\{loginUser}";
            try
            {
                using (DirectoryEntry entry = new DirectoryEntry(ldapServerName, userName, password))
                {
                    using(DirectorySearcher directorySearcher = new DirectorySearcher(entry))
                    {
                        directorySearcher.SearchScope = SearchScope.Subtree;
                        directorySearcher.Filter = $"(&(objectclass=person)(cn={loginUser}))";
                        SearchResult searchResult = directorySearcher.FindOne();
                        if (searchResult == null)
                        {
                            return null;
                        }
                        else
                        {
                            ADUser adUser = new ADUser(searchResult.Properties);
                            // AD情報一覧表示
                            //foreach (var value in searchResult.GetDirectoryEntry().Properties.Cast<PropertyValueCollection>().OrderBy(x => x.PropertyName))
                            //{
                            //    Console.WriteLine("{0}={1}",value.PropertyName,value.Value.ToString());
                            //}
                            return adUser;
                        }
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
    }

    [DataContract]
    internal class BodyContent
    {
        /// <summary>ユーザー名</summary>
        [DataMember]
        internal string username { get; set; }

        /// <summary>パスワード</summary>
        [DataMember]
        internal string password { get; set; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="username">ユーザー名</param>
        /// <param name="password">パスワード</param>
        internal BodyContent(string username, string password)
        {
            this.username = username;
            this.password = password;
        }
    }
}
