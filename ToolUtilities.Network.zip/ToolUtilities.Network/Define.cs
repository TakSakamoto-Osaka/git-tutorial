﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIL.Hyd.ToolUtilities.Network
{
    /// <summary>社員の種類</summary>
    public enum EEmployeeType
    {
        /// <summary>正社員</summary>
        Regular,
        Other,
    }
}
