﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Net.Http;

using DIL.Hyd.ToolUtilities.Network;
using static DIL.Hyd.ToolUtilities.Network.ProtocolType;

namespace DIL.Hyd.DB.PlantAux.SUTAGV
{
    public class SUTAgvAPI : RestAPICom
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="WC">W/C</param>
        /// <param name="strHTTPSrvIP">HTTPサーバーIPアドレス</param>
        /// <param name="ProtocolTypeVal">通信プロトコル種類</param>
        /// <param name="PortNo">HTTPポート番号</param>
        public SUTAgvAPI( string strHTTPSrvIP, ProtocolType ProtocolTypeVal = HTTP, int PortNo = 80 ) : base( strHTTPSrvIP, ProtocolTypeVal, PortNo )
        {
            this.WellKnownTopDir = "sut1-cell-optimization/api";
        }

        /// <summary>
        /// 自動コース取得 
        /// </summary>
        /// <param name="ss_no">生産指示番号</param>
        /// <returns></returns>
        public async Task<CourceData> GetCourceData( string WC, string Cell )
        {
            try {
                List<string> strDirs = new List<string>();

                if ( PortNo == 80 || PortNo == 443 ) {                  //  Well knownポートの場合
                    strDirs.Add( WellKnownTopDir );
                }

                strDirs.AddRange( new string[] { "production-carrying", WC, Cell } );

                string response    = await GetCmd( strDirs );                               //  GET通信
                CourceData reqData = null;

                if ( response != "" ) {                 //  レスポンスデータがある場合
                    reqData = JsonSerializer.DeSerialize<CourceData>( response );           //  取得したJSONデータをクラスオブジェクトに変換
                }

                return ( reqData );

            } catch {
                throw;
            }
        }

        /// <summary>
        /// 銘板刻印ステータス更新
        /// </summary>
        /// <param name="SSNo"></param>
        /// <param name="LotNo"></param>
        /// <param name="stat"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> StatUpdate( string WC, string Cell, string SSNo )
        {
            try {
                List<string> strDirs = new List<string>();

                if ( PortNo == 80 || PortNo == 443 ) {          //  Well knownポートの場合
                    strDirs.Add( WellKnownTopDir );
                }

                strDirs.AddRange( new string[] { "production-carrying", WC, Cell, SSNo } );

                return ( await PutCmd( strDirs ) );            //  PUT通信

            } catch ( Exception ex ) {
                System.Diagnostics.Debug.WriteLine( ex.Message );
                throw;
            }
        }

    }

    /// <summary>
    /// コースデータクラス
    /// </summary>
    [DataContract]
    public class CourceData
    {
        [DataMember]
        /// <summary>生産指示番号</summary>
        public string SSNo { get; set; }

        [DataMember]
        /// <summary>品名コード</summary>
        public string ModelTypeName { get; set; }

        [DataMember]
        /// <summary>セル</summary>
        public string Cell { get; set; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public CourceData()
        {

        }
    }
}
